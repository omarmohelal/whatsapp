export const DEFAULT_BUSINESS = {
  name: 'TheNexus',
  slug: 'thenexus'
} as const;

export const TOP_UP_CLARIFYING_QUESTION =
  'تمام، ابعتلي اسم اللعبة والسيرفر / Region والبكدج اللي محتاجها وهنأكدلك التفاصيل.';

export const ACCOUNT_LISTING_REPLY = `تمام، نقدر نعرض الأكونت بتاعك بسهولة. املى الفورم ده:
https://www.thenexus.ink/

جوا الفورم اكتب كل التفاصيل:
- عدد الـ Blue Essence
- الرانك الحالي
- عدد السكينات
- السيرفر / Region
- Title واضح للأكونت
- Description فيه أهم التفاصيل
- صور أو فيديو للأكونت

لو عارف السعر اكتبه، ولو مش عارف السعر سيبه وهنخلي أدمن يسعره.

مهم جدًا:
- شيل 2FA
- شيل أي رقم موبايل
- شيل أي Recovery Email
- اتأكد إن كل البيانات صح.`;
