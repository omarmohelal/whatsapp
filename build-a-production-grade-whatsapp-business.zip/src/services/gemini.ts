import { GoogleGenerativeAI } from '@google/generative-ai';
import type { Env } from '../config/env';
import { AI_FALLBACK_REPLY, GEMINI_MISSING_KEY_REPLY } from '../config/constants';
import type { AppLogger } from '../logger';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AiClient {
  createEmbedding(input: string): Promise<number[]>;
  createChatCompletion(messages: ChatMessage[]): Promise<string>;
}

export interface GeminiReplyInput {
  systemPrompt: string;
  context?: string;
  recentMessages?: ChatMessage[];
  userMessage: string;
}

const DEFAULT_EMBEDDING_SIZE = 768;

function normalizeEmbedding(values: number[], size = DEFAULT_EMBEDDING_SIZE): number[] {
  if (values.length === size) {
    return values;
  }
  if (values.length > size) {
    return values.slice(0, size);
  }
  return [...values, ...Array.from({ length: size - values.length }, () => 0)];
}

function uniq(values: string[]) {
  return values.map((value) => value.trim()).filter(Boolean).filter((value, index, array) => array.indexOf(value) === index);
}

function messagesToGeminiText(messages: ChatMessage[]): string {
  return messages.map((message) => `${message.role.toUpperCase()}:\n${message.content}`).join('\n\n');
}

async function sleep(ms: number) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

function isNotFoundModelError(error: unknown) {
  const text = error instanceof Error ? `${error.name} ${error.message}` : String(error);
  return /404|not found|not supported|not available/i.test(text);
}

export class GeminiService implements AiClient {
  private readonly client?: GoogleGenerativeAI;

  constructor(
    private readonly env: Env,
    private readonly logger?: Pick<AppLogger, 'warn' | 'error' | 'info'>
  ) {
    const apiKey = process.env.GEMINI_API_KEY || env.GEMINI_API_KEY;
    if (apiKey) {
      this.client = new GoogleGenerativeAI(apiKey);
    }
  }

  async generateGeminiReply(input: GeminiReplyInput): Promise<string> {
    return this.createChatCompletion([
      { role: 'system', content: input.systemPrompt },
      ...(input.recentMessages ?? []),
      {
        role: 'user',
        content: `${input.context ? `Approved context:\n${input.context}\n\n` : ''}Customer message:\n${
          input.userMessage
        }`
      }
    ]);
  }

  async createEmbedding(input: string): Promise<number[]> {
    const client = this.client;
    if (!client) {
      this.logger?.warn('GEMINI_API_KEY is missing; skipping Gemini embedding');
      return [];
    }

    const candidates = uniq([
      this.env.GEMINI_EMBEDDING_MODEL,
      process.env.GEMINI_EMBEDDING_MODEL || '',
      'text-embedding-004',
      'gemini-embedding-001',
      'embedding-001'
    ]);

    for (const modelName of candidates) {
      try {
        return await this.withRetry('gemini_embedding', async () => {
          const model = client.getGenerativeModel({ model: modelName });
          const result = await model.embedContent(input);
          return normalizeEmbedding(result.embedding.values ?? []);
        });
      } catch (error) {
        this.logger?.warn({ err: error, modelName }, 'Gemini embedding model failed');
        if (!isNotFoundModelError(error)) {
          break;
        }
      }
    }

    // Knowledge search is helpful but must never stop the bot from replying.
    this.logger?.warn('All Gemini embedding models failed; continuing without RAG context');
    return [];
  }

  async createChatCompletion(messages: ChatMessage[]): Promise<string> {
    const client = this.client;
    if (!client) {
      this.logger?.warn('GEMINI_API_KEY is missing; returning safe Gemini fallback');
      return GEMINI_MISSING_KEY_REPLY;
    }

    const candidates = uniq([
      this.env.GEMINI_CHAT_MODEL,
      process.env.GEMINI_CHAT_MODEL || '',
      'gemini-2.0-flash',
      'gemini-2.5-flash',
      'gemini-1.5-flash-latest',
      'gemini-1.5-flash'
    ]);

    for (const modelName of candidates) {
      try {
        const reply = await this.withRetry('gemini_chat', async () => {
          const model = client.getGenerativeModel({
            model: modelName,
            generationConfig: {
              temperature: 0.55,
              topP: 0.9,
              maxOutputTokens: 520
            }
          });
          const result = await model.generateContent(messagesToGeminiText(messages));
          return result.response.text().trim();
        });

        if (modelName !== this.env.GEMINI_CHAT_MODEL) {
          this.logger?.warn({ modelName }, 'Gemini chat succeeded using fallback model');
        }
        return reply;
      } catch (error) {
        this.logger?.warn({ err: error, modelName }, 'Gemini chat model failed');
        if (!isNotFoundModelError(error)) {
          break;
        }
      }
    }

    this.logger?.error('All Gemini chat models failed; returning safe fallback');
    return AI_FALLBACK_REPLY;
  }

  private async withRetry<T>(operation: string, fn: () => Promise<T>): Promise<T> {
    const delays = [250, 750, 1500];
    let lastError: unknown;

    for (let attempt = 0; attempt <= delays.length; attempt += 1) {
      try {
        if (attempt > 0) {
          this.logger?.warn({ operation, attempt: attempt + 1 }, 'Retrying Gemini operation');
        }
        const result = await fn();
        this.logger?.info({ operation, attempt: attempt + 1 }, 'Gemini operation succeeded');
        return result;
      } catch (error) {
        lastError = error;
        this.logger?.warn({ err: error, operation, attempt: attempt + 1 }, 'Gemini operation failed');
        if (attempt < delays.length) {
          await sleep(delays[attempt]);
        }
      }
    }

    throw lastError instanceof Error ? lastError : new Error(`${operation} failed`);
  }
}

export async function generateGeminiReply(args: {
  env: Env;
  logger?: Pick<AppLogger, 'warn' | 'error' | 'info'>;
  input: GeminiReplyInput;
}) {
  return new GeminiService(args.env, args.logger).generateGeminiReply(args.input);
}

export async function generateEmbedding(args: {
  env: Env;
  logger?: Pick<AppLogger, 'warn' | 'error' | 'info'>;
  text: string;
}) {
  return new GeminiService(args.env, args.logger).createEmbedding(args.text);
}
