import OpenAI from 'openai';
import type { Env } from '../config/env';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AiClient {
  createEmbedding(input: string): Promise<number[]>;
  createChatCompletion(messages: ChatMessage[]): Promise<string>;
}

export class OpenAiService implements AiClient {
  private readonly client: OpenAI;

  constructor(private readonly env: Env) {
    this.client = new OpenAI({ apiKey: env.OPENAI_API_KEY });
  }

  async createEmbedding(input: string): Promise<number[]> {
    const response = await this.client.embeddings.create({
      model: this.env.OPENAI_EMBEDDING_MODEL,
      input
    });

    return response.data[0]?.embedding ?? [];
  }

  async createChatCompletion(messages: ChatMessage[]): Promise<string> {
    const response = await this.client.chat.completions.create({
      model: this.env.OPENAI_CHAT_MODEL,
      messages,
      temperature: 0.2
    });

    return response.choices[0]?.message?.content?.trim() ?? '';
  }
}
