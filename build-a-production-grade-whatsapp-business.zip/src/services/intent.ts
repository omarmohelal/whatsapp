export type IntentName =
  | 'top_up'
  | 'league_rp'
  | 'riot_gift'
  | 'account_sell'
  | 'account_buy'
  | 'complaint'
  | 'refund'
  | 'payment_issue'
  | 'unrelated'
  | 'general';

export interface IntentResult {
  name: IntentName;
  confidence: number;
  entities: {
    game?: 'wild_rift' | 'league' | 'clash' | 'general';
    asksForPrice?: boolean;
    unknownAccountPrice?: boolean;
  };
}

const includesAny = (text: string, needles: string[]) =>
  needles.some((needle) => text.includes(needle));

export function normalizeForIntent(text: string): string {
  return text.toLowerCase().replace(/\s+/g, ' ').trim();
}

export function hasUnknownAccountPrice(text: string): boolean {
  const normalized = normalizeForIntent(text);
  return includesAny(normalized, [
    'مش عارف السعر',
    'مش عارف سعر',
    'معرفش السعر',
    'مش عارف ابيع بكام',
    'سعره كام',
    "don't know the price",
    'dont know the price',
    'not sure price',
    'price it for me'
  ]);
}

export function asksForPrice(text: string): boolean {
  const normalized = normalizeForIntent(text);
  return includesAny(normalized, ['price', 'cost', 'بكام', 'كام', 'سعر', 'اسعار', 'الأسعار']);
}

export function classifyIntent(text: string): IntentResult {
  const normalized = normalizeForIntent(text);
  const entities: IntentResult['entities'] = {
    asksForPrice: asksForPrice(text),
    unknownAccountPrice: hasUnknownAccountPrice(text)
  };

  if (includesAny(normalized, ['wild rift', 'وايلد ريفت', 'wildrift'])) {
    entities.game = 'wild_rift';
  } else if (includesAny(normalized, ['league', 'lol', 'rp', 'ليج', 'ليج اوف ليجندز'])) {
    entities.game = 'league';
  } else if (includesAny(normalized, ['clash', 'كلاش'])) {
    entities.game = 'clash';
  }

  if (
    includesAny(normalized, [
      'refund',
      'استرجاع',
      'رجع فلوسي',
      'عايز فلوسي',
      'chargeback',
      'استرداد'
    ])
  ) {
    return { name: 'refund', confidence: 0.95, entities };
  }

  if (
    includesAny(normalized, [
      'payment',
      'paid',
      'دفع',
      'دفعت',
      'تحويل',
      'فودافون كاش',
      'instapay',
      'انستاباي',
      'وصل الدفع'
    ])
  ) {
    return { name: 'payment_issue', confidence: 0.9, entities };
  }

  if (includesAny(normalized, ['complaint', 'شكوى', 'مشكلة', 'اتأخر', 'متاخر', 'غلط'])) {
    return { name: 'complaint', confidence: 0.85, entities };
  }

  if (
    includesAny(normalized, [
      'sell account',
      'list account',
      'بيع اكونت',
      'ابيع اكونت',
      'اعرض اكونت',
      'اعرض الأكونت',
      'اكونتي للبيع',
      'بيع حساب'
    ])
  ) {
    return { name: 'account_sell', confidence: 0.95, entities };
  }

  if (
    includesAny(normalized, [
      'buy account',
      'buy an account',
      'اشتري اكونت',
      'عايز اكونت',
      'عايز اشتري حساب',
      'شراء حساب',
      'account to buy'
    ])
  ) {
    return { name: 'account_buy', confidence: 0.92, entities };
  }

  if (
    includesAny(normalized, [
      'skin',
      'skins',
      'gift',
      'gifting',
      'جيفت',
      'جفت',
      'هدية',
      'سكنات',
      'riot gift'
    ])
  ) {
    return { name: 'riot_gift', confidence: 0.88, entities };
  }

  if (entities.game === 'league' && includesAny(normalized, ['rp', 'ار بي', 'rp شحن'])) {
    return { name: 'league_rp', confidence: 0.92, entities };
  }

  if (
    entities.game ||
    includesAny(normalized, [
      'top up',
      'topup',
      'shipping',
      'charge',
      'شحن',
      'اشحن',
      'باكدج',
      'بكدج',
      'package'
    ])
  ) {
    entities.game ??= 'general';
    return { name: 'top_up', confidence: 0.9, entities };
  }

  if (
    includesAny(normalized, [
      'homework',
      'weather',
      'سياسة',
      'اخبار',
      'recipe',
      'طبخة',
      'medical',
      'doctor'
    ])
  ) {
    return { name: 'unrelated', confidence: 0.8, entities };
  }

  return { name: 'general', confidence: 0.45, entities };
}
