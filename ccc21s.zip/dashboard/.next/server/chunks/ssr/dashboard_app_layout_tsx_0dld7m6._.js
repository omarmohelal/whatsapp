module.exports=[58005,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{children:a})})},"metadata",0,{title:"TheNexus Dashboard",description:"WhatsApp Business AI Agent admin dashboard"}])},23442,a=>{a.n(a.i(58005))}];

//# sourceMappingURL=dashboard_app_layout_tsx_0dld7m6._.js.map