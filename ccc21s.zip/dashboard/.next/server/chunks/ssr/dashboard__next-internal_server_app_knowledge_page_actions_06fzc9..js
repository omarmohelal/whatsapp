module.exports=[3520,(a,b,c)=>{}];

//# sourceMappingURL=dashboard__next-internal_server_app_knowledge_page_actions_06fzc9..js.map