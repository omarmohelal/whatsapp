module.exports=[64794,(a,b,c)=>{}];

//# sourceMappingURL=dashboard__next-internal_server_app_analytics_page_actions_0i02g36.js.map