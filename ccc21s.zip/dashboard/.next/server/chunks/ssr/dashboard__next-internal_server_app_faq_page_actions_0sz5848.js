module.exports=[50889,(a,b,c)=>{}];

//# sourceMappingURL=dashboard__next-internal_server_app_faq_page_actions_0sz5848.js.map