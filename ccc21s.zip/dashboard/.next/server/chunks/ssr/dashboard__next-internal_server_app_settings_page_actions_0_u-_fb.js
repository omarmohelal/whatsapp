module.exports=[52573,(a,b,c)=>{}];

//# sourceMappingURL=dashboard__next-internal_server_app_settings_page_actions_0_u-_fb.js.map