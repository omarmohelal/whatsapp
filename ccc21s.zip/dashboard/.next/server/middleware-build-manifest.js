globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/9-BXt3layRuO_wUXbxrR1/_buildManifest.js",
    "static/9-BXt3layRuO_wUXbxrR1/_ssgManifest.js",
    "static/9-BXt3layRuO_wUXbxrR1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00gq-v0e07i1q.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0c7h~x4_chf35.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0zj5ebpug2h3b.js"
  ]
};
